# LAST FIVE — Product & Engineering Specification

## Game contract
- Room size: exactly five players at match start.
- The server creates challenge and deadline; clients display both.
- Video upload uses a private object-storage bucket and short-lived signed upload URLs.
- Server records receipt only after storage confirms the object and validates ownership/size/type.
- If every active player submits, the latest server-received submission is eliminated.
- If deadline expires with missing submissions, choose one non-submitter using an explicitly published policy. Current scaffold uses earliest join among missing as a placeholder policy; product/legal review should decide whether random selection or all-missing elimination is better.
- Match finishes when exactly one active player remains.
- Disputes and moderation do not alter round ordering except through auditable admin action.

## Recommended safety guardrails
- Challenges may not require dangerous stunts, nudity, illegal acts, trespassing, harassment, personal data disclosure, or consuming substances.
- Include “skip for safety” with no penalty and a report flow; decide its game rule before release.
- For minors, add age-aware privacy, upload visibility defaults, parental/legal review and region-specific compliance.
- Videos private by default; share only with explicit consent.
- Retention setting, deletion requests and account deletion must be implemented server-side.
- Moderation queue, report categories, appeals, and human review are required for a public release.

## Release readiness (not yet complete)
- Production auth (OIDC/email verification/password reset, rate limits)
- PostgreSQL persistence and migrations
- Redis distributed locks and WebSocket gateway
- Signed video upload/download URLs, transcoding, limits and deletion
- Server-side match transactions/idempotency
- Push notifications (FCM/APNs)
- Anti-cheat telemetry, admin RBAC, audit log enforcement
- Localization, accessibility, device testing, app store assets
- Privacy policy, terms, community rules, consent and age gates
- Load/security testing and observability
