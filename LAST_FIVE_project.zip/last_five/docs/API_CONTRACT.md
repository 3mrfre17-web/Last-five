# API contract (starter)

Base: `/api/v1`

- `GET /game/health` — health
- `POST /game/rooms` `{hostId}` — create room
- `POST /game/rooms/join` `{roomCode, playerId}` — join a waiting room
- `POST /game/rooms/start` `{roomCode, hostId}` — start once five are present
- `POST /game/submissions` `{roomCode, playerId, videoKey}` — record server receipt
- `POST /game/rounds/resolve` `{roomCode, actorId}` — resolve demo round

Production API must authenticate every call and derive player/admin identity from the access token, not body fields. The current Nest scaffold intentionally exposes a minimal demonstration contract and uses in-memory rooms.
