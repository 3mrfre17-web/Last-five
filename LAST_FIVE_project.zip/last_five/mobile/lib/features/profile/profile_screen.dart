import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الملف الشخصي')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      LfPanel(child: Column(children: [
        Container(width: 92, height: 92, decoration: BoxDecoration(shape: BoxShape.circle,
          gradient: const LinearGradient(colors: [lfPurple, lfRed]), border: Border.all(color: lfPurpleBright, width: 3)),
          child: const Icon(Icons.person, size: 54, color: Colors.white)),
        const SizedBox(height: 12), const Text('PLAYER_05', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        const Text('@lastfive_player', style: TextStyle(color: lfMuted)),
        const SizedBox(height: 16), const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.stars, color: Color(0xFFE8C46A)), SizedBox(width: 6),
          Text('المستوى 12 • ناجٍ فضي', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        const SizedBox(height: 14), const LinearProgressIndicator(value: .68, color: lfPurple, backgroundColor: lfSurface2),
        const SizedBox(height: 6), const Text('680 / 1000 XP', style: TextStyle(color: lfMuted, fontSize: 12)),
      ])),
      const SizedBox(height: 18), const SectionTitle('إحصائياتي'), const SizedBox(height: 10),
      const Row(children: [
        Expanded(child: _Stat('18', 'انتصار')), SizedBox(width: 10),
        Expanded(child: _Stat('42', 'مباراة')), SizedBox(width: 10),
        Expanded(child: _Stat('4', 'سلسلة')),
      ]),
      const SizedBox(height: 18), const SectionTitle('الإنجازات'), const SizedBox(height: 10),
      const LfPanel(child: Wrap(spacing: 12, runSpacing: 12, children: [
        _Badge(Icons.emoji_events, 'أول فوز'), _Badge(Icons.local_fire_department, 'ثلاثة متتاليات'),
        _Badge(Icons.shield, 'ناجٍ'), _Badge(Icons.bolt, 'سريع التسليم'),
      ])),
      const SizedBox(height: 18), const SectionTitle('إعدادات الحساب'), const SizedBox(height: 10),
      const LfPanel(child: Column(children: [
        ListTile(leading: Icon(Icons.notifications_outlined), title: Text('الإشعارات'), trailing: Icon(Icons.chevron_left)),
        Divider(height: 1), ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('الخصوصية والفيديوهات'), trailing: Icon(Icons.chevron_left)),
        Divider(height: 1), ListTile(leading: Icon(Icons.language), title: Text('اللغة'), trailing: Text('العربية')),
      ])),
    ]),
  );
}
class _Stat extends StatelessWidget {
  const _Stat(this.value, this.label);
  final String value, label;
  @override
  Widget build(BuildContext context) => LfPanel(padding: const EdgeInsets.all(14), child: Column(children: [
    Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: lfPurpleBright)),
    Text(label, style: const TextStyle(color: lfMuted, fontSize: 12)),
  ]));
}
class _Badge extends StatelessWidget {
  const _Badge(this.icon, this.label);
  final IconData icon; final String label;
  @override
  Widget build(BuildContext context) => Container(width: 110, padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: lfSurface2, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [Icon(icon, color: const Color(0xFFE8C46A), size: 28), const SizedBox(height: 7),
      Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700))]));
}
