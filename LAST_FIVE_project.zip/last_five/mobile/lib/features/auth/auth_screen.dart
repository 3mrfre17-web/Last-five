import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}
class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool signup = false;
  bool obscure = true;

  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 480), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 22),
          Container(height: 92, width: 92, alignment: Alignment.center,
            decoration: BoxDecoration(shape: BoxShape.circle, color: lfPurple.withValues(alpha: .13),
              border: Border.all(color: lfPurple.withValues(alpha: .5))),
            child: const Icon(Icons.flash_on_rounded, size: 48, color: lfPurpleBright)),
          const SizedBox(height: 20),
          const Text('LAST FIVE', textAlign: TextAlign.center,
            style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 2)),
          const SizedBox(height: 8),
          const Text('خمسة يدخلون… وواحد فقط ينجو', textAlign: TextAlign.center,
            style: TextStyle(color: lfMuted, fontSize: 15)),
          const SizedBox(height: 34),
          LfPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(signup ? 'إنشاء حساب جديد' : 'مرحبًا بعودتك',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 18),
            TextField(controller: email, keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'البريد الإلكتروني', prefixIcon: Icon(Icons.mail_outline))),
            const SizedBox(height: 12),
            TextField(controller: password, obscureText: obscure,
              decoration: InputDecoration(labelText: 'كلمة المرور', prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: IconButton(icon: Icon(obscure ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => obscure = !obscure))),
            ),
            const SizedBox(height: 18),
            NeonButton(label: signup ? 'إنشاء الحساب' : 'تسجيل الدخول',
              onTap: () => context.go('/home'), icon: Icons.arrow_forward_rounded),
            const SizedBox(height: 10),
            TextButton(onPressed: () => setState(() => signup = !signup),
              child: Text(signup ? 'لديك حساب؟ تسجيل الدخول' : 'ليس لديك حساب؟ أنشئ حسابًا')),
            const Text('وضع العرض: الدخول هنا محلي لتجربة الواجهات. اربط المصادقة بالخادم قبل الإطلاق.',
              textAlign: TextAlign.center, style: TextStyle(color: lfMuted, fontSize: 11)),
          ])),
          const SizedBox(height: 24),
          const Text('لعب عادل • تحديات آمنة • لحظات لا تُنسى',
            textAlign: TextAlign.center, style: TextStyle(color: lfMuted, fontSize: 12)),
        ],
      ))),
    )),
  );
}
