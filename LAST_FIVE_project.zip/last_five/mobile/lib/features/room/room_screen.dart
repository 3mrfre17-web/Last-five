import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';

class RoomScreen extends StatefulWidget {
  const RoomScreen({super.key});
  @override
  State<RoomScreen> createState() => _RoomScreenState();
}
class _RoomScreenState extends State<RoomScreen> {
  int round = 1;
  int alive = 5;
  bool submitted = false;
  bool started = false;
  final code = 'LF-${Random(5).nextInt(8999) + 1000}';
  final challenges = const [
    'نفّذ أفضل تعبير وجه مضحك خلال 10 ثوانٍ.',
    'مثّل مشهدًا كأنك فزت بجائزة عالمية.',
    'قل جملة صعبة بسرعة ثلاث مرات دون خطأ.',
    'ابتكر إعلانًا مرتجلًا لشيء موجود بجانبك.',
    'قلّد روبوتًا لمدة 15 ثانية.',
  ];
  @override
  Widget build(BuildContext context) {
    final players = ['أنت', 'NOVA', 'M7MD', 'LUNA', 'KOKO'];
    return Scaffold(
      appBar: AppBar(title: const Text('غرفة التحدي'), leading: IconButton(onPressed: () => Navigator.of(context).maybePop(), icon: const Icon(Icons.arrow_back))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        LfPanel(child: Column(children: [
          const Text('كود الغرفة', style: TextStyle(color: lfMuted)),
          const SizedBox(height: 4), Text(code, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: 2, color: lfPurpleBright)),
          const SizedBox(height: 12), Text('$alive / 5 لاعبين باقون', style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 12), const LinearProgressIndicator(value: 1, color: lfPurple, backgroundColor: lfSurface2),
        ])),
        const SizedBox(height: 18),
        const SectionTitle('اللاعبون'),
        const SizedBox(height: 10),
        ...List.generate(5, (i) => Padding(padding: const EdgeInsets.only(bottom: 8), child: LfPanel(padding: const EdgeInsets.all(12),
          child: Row(children: [
            CircleAvatar(backgroundColor: [lfPurple, lfRed, const Color(0xFF3C9DCA), const Color(0xFF56D6A2), const Color(0xFFE5B85C)][i],
              child: Text(players[i][0], style: const TextStyle(fontWeight: FontWeight.w900))),
            const SizedBox(width: 12), Expanded(child: Text(players[i], style: const TextStyle(fontWeight: FontWeight.w700))),
            Text(i < alive ? (i == 0 && submitted ? 'تم التسليم' : 'مستعد') : 'مُقصى',
              style: TextStyle(color: i < alive ? (i == 0 && submitted ? lfGreen : lfMuted) : lfRed, fontSize: 12)),
          ])))),
        const SizedBox(height: 10),
        LfPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('الجولة $round', style: const TextStyle(color: lfPurpleBright, fontWeight: FontWeight.w800)),
            const Icon(Icons.gavel_rounded, color: lfPurpleBright),
          ]),
          const SizedBox(height: 12),
          Text(started ? challenges[(round - 1) % challenges.length] : 'الحكم ينتظر بدء المباراة…',
            style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          const Text('المهلة التجريبية: 60 ثانية', style: TextStyle(color: lfMuted)),
          const SizedBox(height: 16),
          if (!started) NeonButton(label: 'بدء المباراة', icon: Icons.play_arrow, onTap: () => setState(() => started = true))
          else NeonButton(label: submitted ? 'تم استلام الفيديو ✓' : 'تصوير وإرسال التحدي',
            icon: submitted ? Icons.check_circle : Icons.videocam,
            onTap: submitted ? () {} : () => setState(() => submitted = true),
          ),
          const SizedBox(height: 10),
          if (started) OutlinedButton.icon(
            onPressed: () => setState(() { if (alive > 2) { alive--; round++; submitted = false; } else { alive = 1; } }),
            icon: const Icon(Icons.gavel), label: const Text('محاكاة قرار الحكم — الجولة التالية'),
          ),
          const Text('ملاحظة: هذه غرفة تجريبية محلية. الفيديو والنتيجة الفعلية يحتاجان خادمًا موثوقًا.',
            style: TextStyle(color: lfMuted, fontSize: 11)),
        ])),
      ]),
    );
  }
}
