import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مركز الإدارة')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const LfPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('نظرة عامة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        SizedBox(height: 5), Text('أرقام تجريبية للعرض — ليست بيانات حية.', style: TextStyle(color: lfMuted, fontSize: 12)),
      ])),
      const SizedBox(height: 12),
      const Row(children: [Expanded(child: _Metric('1,284', 'لاعبًا')), SizedBox(width: 10), Expanded(child: _Metric('36', 'غرفة نشطة'))]),
      const SizedBox(height: 10),
      const Row(children: [Expanded(child: _Metric('8,902', 'مباراة')), SizedBox(width: 10), Expanded(child: _Metric('12', 'بلاغًا'))]),
      const SizedBox(height: 20), const SectionTitle('أدوات الإدارة'), const SizedBox(height: 10),
      ...[
        (Icons.people_outline, 'إدارة اللاعبين', 'حسابات، حظر، وتحقق'),
        (Icons.meeting_room_outlined, 'إدارة الغرف', 'مراقبة المباريات وإغلاق الغرف'),
        (Icons.gavel_outlined, 'مكتبة التحديات', 'تصنيف وتحرير التحديات'),
        (Icons.video_library_outlined, 'مراجعة الفيديو', 'البلاغات والمحتوى'),
        (Icons.analytics_outlined, 'التحليلات', 'الاحتفاظ ومؤشرات الأداء'),
        (Icons.security_outlined, 'الأمان وسجل التدقيق', 'صلاحيات وتسجيل عمليات'),
      ].map((item) => Padding(padding: const EdgeInsets.only(bottom: 8), child: LfPanel(child: ListTile(
        leading: Icon(item.$1, color: lfPurpleBright), title: Text(item.$2, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(item.$3, style: const TextStyle(color: lfMuted, fontSize: 12)), trailing: const Icon(Icons.chevron_left),
        onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تتطلب صلاحيات إدارة موثقة وخادمًا متصلًا.'))),
      )))),
    ]),
  );
}
class _Metric extends StatelessWidget {
  const _Metric(this.value, this.label);
  final String value, label;
  @override
  Widget build(BuildContext context) => LfPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: lfPurpleBright)),
    Text(label, style: const TextStyle(color: lfMuted, fontSize: 12)),
  ]));
}
