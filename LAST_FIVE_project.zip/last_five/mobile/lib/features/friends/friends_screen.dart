import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';

class FriendsScreen extends StatefulWidget {
  const FriendsScreen({super.key});
  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}
class _FriendsScreenState extends State<FriendsScreen> {
  final search = TextEditingController();
  final friends = ['NOVA', 'M7MD', 'LUNA', 'KOKO'];
  @override
  void dispose() { search.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الأصدقاء')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      TextField(controller: search, decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ابحث باسم اللاعب أو الكود')),
      const SizedBox(height: 18),
      const SectionTitle('متصلون الآن', trailing: Text('4', style: TextStyle(color: lfPurpleBright))),
      const SizedBox(height: 10),
      ...friends.map((name) => Padding(padding: const EdgeInsets.only(bottom: 8), child: LfPanel(child: Row(children: [
        const CircleAvatar(backgroundColor: Color(0xFF30224D), child: Icon(Icons.person, color: lfPurpleBright)),
        const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name, style: const TextStyle(fontWeight: FontWeight.w800)), const Text('متصل • جاهز للعب', style: TextStyle(color: lfGreen, fontSize: 11)),
        ])),
        IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم إرسال دعوة إلى $name'))),
          icon: const Icon(Icons.person_add_alt_1, color: lfPurpleBright)),
      ])))),
      const SizedBox(height: 14),
      NeonButton(label: 'إضافة صديق', icon: Icons.add, onTap: () => showDialog(context: context, builder: (_) => AlertDialog(
        backgroundColor: lfSurface, title: const Text('إضافة صديق'),
        content: const TextField(decoration: InputDecoration(hintText: 'اسم اللاعب أو كود الصديق')),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () { Navigator.pop(context); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سيتم ربط طلبات الصداقة بالخادم.'))); }, child: const Text('إرسال الطلب'))],
      ))),
    ]),
  );
}
