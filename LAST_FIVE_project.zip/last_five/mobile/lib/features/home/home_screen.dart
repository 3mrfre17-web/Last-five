import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('LAST FIVE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5)),
      actions: [IconButton(onPressed: () => context.go('/profile'), icon: const Icon(Icons.account_circle_outlined))]),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: const LinearGradient(colors: [Color(0xFF3D246D), Color(0xFF191421)], begin: Alignment.topRight, end: Alignment.bottomLeft),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('هل أنت مستعد للنجاة؟', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text('خمسة لاعبين. تحديات متصاعدة. فائز واحد.', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 22),
          NeonButton(label: 'إنشاء غرفة جديدة', icon: Icons.add_circle_outline, onTap: () => context.go('/room')),
        ]),
      ),
      const SizedBox(height: 22),
      const SectionTitle('العب الآن'),
      const SizedBox(height: 12),
      _ModeCard(icon: Icons.groups_rounded, title: 'غرفة الأصدقاء', subtitle: 'أنشئ غرفة خاصة وشارك كود الدعوة', tag: 'الأكثر لعبًا',
        onTap: () => context.go('/room')),
      const SizedBox(height: 10),
      _ModeCard(icon: Icons.bolt_rounded, title: 'اللعب السريع', subtitle: 'انضم إلى لاعبين يبحثون عن مباراة', tag: 'قريبًا',
        onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سيتم تفعيل المطابقة عند ربط الخادم.')))),
      const SizedBox(height: 22),
      const SectionTitle('مهمتك اليومية'),
      const SizedBox(height: 12),
      const LfPanel(child: Row(children: [
        CircleAvatar(backgroundColor: Color(0xFF34254F), child: Icon(Icons.local_fire_department, color: lfPurpleBright)),
        SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('شارك في مباراة واحدة', style: TextStyle(fontWeight: FontWeight.w700)),
          SizedBox(height: 4), Text('المكافأة: 100 XP', style: TextStyle(color: lfMuted, fontSize: 12)),
        ])), Text('0/1', style: TextStyle(color: lfPurpleBright, fontWeight: FontWeight.w800))
      ])),
      const SizedBox(height: 22),
      Row(children: [
        Expanded(child: _QuickLink(icon: Icons.people_alt_outlined, label: 'الأصدقاء', onTap: () => context.go('/friends'))),
        const SizedBox(width: 10),
        Expanded(child: _QuickLink(icon: Icons.person_outline, label: 'ملفي', onTap: () => context.go('/profile'))),
        const SizedBox(width: 10),
        Expanded(child: _QuickLink(icon: Icons.admin_panel_settings_outlined, label: 'الإدارة', onTap: () => context.go('/admin'))),
      ]),
    ]),
  );
}

class _ModeCard extends StatelessWidget {
  const _ModeCard({required this.icon, required this.title, required this.subtitle, required this.tag, required this.onTap});
  final IconData icon; final String title, subtitle, tag; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(20),
    child: LfPanel(child: Row(children: [
      Container(width: 50, height: 50, decoration: BoxDecoration(color: lfPurple.withValues(alpha: .14), borderRadius: BorderRadius.circular(15)),
        child: Icon(icon, color: lfPurpleBright, size: 28)),
      const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: lfMuted, fontSize: 12)),
      ])), Text(tag, style: const TextStyle(color: lfPurpleBright, fontSize: 11, fontWeight: FontWeight.w700))
    ])));
}
class _QuickLink extends StatelessWidget {
  const _QuickLink({required this.icon, required this.label, required this.onTap});
  final IconData icon; final String label; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, child: LfPanel(padding: const EdgeInsets.symmetric(vertical: 15),
    child: Column(children: [Icon(icon, color: lfPurpleBright), const SizedBox(height: 7), Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700))])));
}
