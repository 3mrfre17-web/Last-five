import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

const lfBackground = Color(0xFF0B0B12);
const lfSurface = Color(0xFF171722);
const lfSurface2 = Color(0xFF20202D);
const lfPurple = Color(0xFF9B72FF);
const lfPurpleBright = Color(0xFFB59AFF);
const lfRed = Color(0xFFFF526C);
const lfText = Color(0xFFF6F3FF);
const lfMuted = Color(0xFFAAA7BC);
const lfGreen = Color(0xFF56D6A2);

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: lfBackground,
    colorScheme: const ColorScheme.dark(
      primary: lfPurple,
      secondary: lfRed,
      surface: lfSurface,
      error: lfRed,
    ),
    textTheme: GoogleFonts.tajawalTextTheme(base.textTheme).apply(
      bodyColor: lfText,
      displayColor: lfText,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: lfBackground,
      foregroundColor: lfText,
      elevation: 0,
      centerTitle: false,
    ),
    cardTheme: CardTheme(
      color: lfSurface,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: lfSurface2,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),
      hintStyle: const TextStyle(color: lfMuted),
    ),
  );
}
