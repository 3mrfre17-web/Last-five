import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import 'features/auth/auth_screen.dart';
import 'features/home/home_screen.dart';
import 'features/room/room_screen.dart';
import 'features/profile/profile_screen.dart';
import 'features/friends/friends_screen.dart';
import 'features/admin/admin_screen.dart';
import 'core/theme.dart';

class LastFiveApp extends StatelessWidget {
  const LastFiveApp({super.key});

  @override
  Widget build(BuildContext context) {
    final router = GoRouter(
      initialLocation: '/login',
      routes: [
        GoRoute(path: '/login', builder: (_, __) => const AuthScreen()),
        GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),
        GoRoute(path: '/room', builder: (_, __) => const RoomScreen()),
        GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
        GoRoute(path: '/friends', builder: (_, __) => const FriendsScreen()),
        GoRoute(path: '/admin', builder: (_, __) => const AdminScreen()),
      ],
    );
    return MaterialApp.router(
      title: 'LAST FIVE',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      routerConfig: router,
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
    );
  }
}
