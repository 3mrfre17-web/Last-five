import { Injectable, BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { randomBytes } from 'crypto';

type Player = { id: string; joinedAt: number; eliminated: boolean; submittedAt?: number; videoKey?: string };
type Room = { code: string; hostId: string; players: Player[]; status: 'waiting' | 'live' | 'finished'; round: number; deadline?: number; challenge?: string; history: unknown[] };

@Injectable()
export class GameService {
  // In-memory demonstration only. Replace with PostgreSQL persistence + Redis locks before production.
  private readonly rooms = new Map<string, Room>();
  private readonly challengePool = [
    'نفّذ حركة آمنة ومضحكة لمدة 10 ثوانٍ.',
    'مثّل إعلانًا مرتجلًا لشيء قريب منك.',
    'قل جملة صعبة بسرعة ثلاث مرات دون خطأ.',
    'اصنع تعبير وجه يصف مفاجأة كبيرة.',
  ];

  createRoom(hostId: string) {
    if (!hostId) throw new BadRequestException('hostId is required');
    const code = randomBytes(3).toString('hex').toUpperCase();
    const room: Room = { code, hostId, players: [{ id: hostId, joinedAt: Date.now(), eliminated: false }], status: 'waiting', round: 0, history: [] };
    this.rooms.set(code, room);
    return { roomCode: code, status: room.status, playerCount: 1 };
  }

  joinRoom(roomCode: string, playerId: string) {
    const room = this.findRoom(roomCode);
    if (room.status !== 'waiting') throw new BadRequestException('Room has already started');
    if (room.players.length >= 5) throw new BadRequestException('Room is full');
    if (!playerId || room.players.some(p => p.id === playerId)) throw new BadRequestException('Invalid or duplicate player');
    room.players.push({ id: playerId, joinedAt: Date.now(), eliminated: false });
    return { roomCode, playerCount: room.players.length, slotsRemaining: 5 - room.players.length };
  }

  startMatch(roomCode: string, hostId: string) {
    const room = this.findRoom(roomCode);
    if (room.hostId !== hostId) throw new ForbiddenException('Only host may start');
    if (room.players.length !== 5) throw new BadRequestException('Exactly five players are required');
    if (room.status !== 'waiting') throw new BadRequestException('Room is not waiting');
    room.status = 'live';
    return this.startRound(room);
  }

  submit(roomCode: string, playerId: string, videoKey: string) {
    const room = this.findRoom(roomCode);
    if (room.status !== 'live' || !room.deadline) throw new BadRequestException('No active round');
    if (Date.now() > room.deadline) throw new BadRequestException('Submission deadline passed');
    if (!videoKey || videoKey.startsWith('http')) throw new BadRequestException('Use a storage object key, not a public URL');
    const player = room.players.find(p => p.id === playerId && !p.eliminated);
    if (!player) throw new NotFoundException('Active player not found');
    if (player.submittedAt) throw new BadRequestException('Already submitted');
    // Server receipt time is authoritative. Validate signed upload metadata in production.
    player.submittedAt = Date.now();
    player.videoKey = videoKey;
    return { accepted: true, receivedAt: player.submittedAt };
  }

  resolveRound(roomCode: string, actorId: string) {
    const room = this.findRoom(roomCode);
    if (room.hostId !== actorId) throw new ForbiddenException('Only room host may trigger this demo resolver');
    if (room.status !== 'live') throw new BadRequestException('No live match');
    const active = room.players.filter(p => !p.eliminated);
    const deadlinePassed = Date.now() >= (room.deadline ?? 0);
    const allSubmitted = active.every(p => !!p.submittedAt);
    if (!allSubmitted && !deadlinePassed) throw new BadRequestException('Wait for all submissions or deadline');

    const missing = active.filter(p => !p.submittedAt);
    // Product policy: if several miss, eliminate the earliest-joined among missing;
    // if all submitted, eliminate the latest server-received submission.
    const loser = missing.length
      ? missing.sort((a, b) => a.joinedAt - b.joinedAt)[0]
      : [...active].sort((a, b) => (b.submittedAt ?? 0) - (a.submittedAt ?? 0))[0];
    loser.eliminated = true;
    room.history.push({ round: room.round, eliminatedPlayerId: loser.id, reason: missing.length ? 'missed_deadline' : 'latest_submission' });

    if (room.players.filter(p => !p.eliminated).length === 1) {
      room.status = 'finished';
      return { status: 'finished', winnerId: room.players.find(p => !p.eliminated)?.id, eliminatedPlayerId: loser.id, history: room.history };
    }
    return { ...this.startRound(room), eliminatedPlayerId: loser.id, history: room.history };
  }

  private startRound(room: Room) {
    room.round += 1;
    room.players.forEach(p => { p.submittedAt = undefined; p.videoKey = undefined; });
    room.challenge = this.challengePool[(room.round - 1) % this.challengePool.length];
    room.deadline = Date.now() + 60_000;
    return { roomCode: room.code, status: room.status, round: room.round, challenge: room.challenge, deadline: room.deadline, activePlayers: room.players.filter(p => !p.eliminated).map(p => p.id) };
  }

  private findRoom(code: string) {
    const room = this.rooms.get(code);
    if (!room) throw new NotFoundException('Room not found');
    return room;
  }
}
