import { Body, Controller, Get, Post } from '@nestjs/common';
import { GameService } from './game.service';

@Controller('game')
export class GameController {
  constructor(private readonly game: GameService) {}

  @Get('health')
  health() { return { status: 'ok', service: 'last-five-api' }; }

  @Post('rooms')
  createRoom(@Body() body: { hostId: string }) {
    return this.game.createRoom(body.hostId);
  }

  @Post('rooms/join')
  joinRoom(@Body() body: { roomCode: string; playerId: string }) {
    return this.game.joinRoom(body.roomCode, body.playerId);
  }

  @Post('rooms/start')
  start(@Body() body: { roomCode: string; hostId: string }) {
    return this.game.startMatch(body.roomCode, body.hostId);
  }

  @Post('submissions')
  submit(@Body() body: { roomCode: string; playerId: string; videoKey: string }) {
    return this.game.submit(body.roomCode, body.playerId, body.videoKey);
  }

  @Post('rounds/resolve')
  resolve(@Body() body: { roomCode: string; actorId: string }) {
    return this.game.resolveRound(body.roomCode, body.actorId);
  }
}
