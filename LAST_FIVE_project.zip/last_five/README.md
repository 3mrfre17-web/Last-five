# LAST FIVE — Mobile game starter

A production-oriented Flutter app foundation for a five-player challenge/elimination game.

## Included
- Flutter mobile app structure (Android/iOS)
- Arabic-first RTL interface with dark neon theme
- Auth, home, friends, profile, room, challenge, results and admin screens
- Client-side demo state for room creation and game round progression
- Backend API contract and NestJS scaffold
- PostgreSQL schema, Docker Compose, environment template
- Notes for real-time, video storage, moderation and deployment

> This is a runnable foundation, not a deployed production service. Live authentication, upload storage, AI moderation, and server-authoritative multiplayer must be configured and deployed. The app's demo flow is clearly marked.

## Run Flutter
1. Install Flutter SDK (stable) and Android Studio/Xcode.
2. From `mobile/`: `flutter pub get`
3. `flutter run`

## Run API scaffold
1. Install Node.js 20+.
2. From `server/`: `npm install`
3. Copy `.env.example` to `.env`, configure values.
4. `npm run start:dev`

## Database
`docker compose up -d postgres redis`

## Core rule
The server is authoritative for deadlines, submission ordering, eliminations and winner selection. Client timestamps are informational only. Never use a device clock to decide elimination.
